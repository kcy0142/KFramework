package com.test.command;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import framework.Command;

public class UserCommand1  implements Command {
	public String execute(HttpServletRequest req
			, HttpServletResponse resp) throws ServletException{
		req.setAttribute("message", "This is A Page");
		return "/a1.jsp";
	}
}