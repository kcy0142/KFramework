package framework;

public class CommandFactory {
	public static Command create(String name)throws Exception{
		return (Command)Class.forName(name).newInstance();
	}
} 